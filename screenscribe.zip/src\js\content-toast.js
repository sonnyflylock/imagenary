// Injected modal overlay for showing extraction progress and results

(function () {
  const ID = 'imagenary-modal';

  // Remove existing modal if any
  const existing = document.getElementById(ID);
  if (existing) existing.remove();

  // Backdrop
  const backdrop = document.createElement('div');
  backdrop.id = ID;
  Object.assign(backdrop.style, {
    position: 'fixed',
    top: '0', left: '0', width: '100%', height: '100%',
    zIndex: '2147483647',
    background: 'rgba(0,0,0,0.5)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'opacity 0.25s',
    opacity: '0',
    fontFamily: 'system-ui, -apple-system, sans-serif',
  });

  // Modal card
  const modal = document.createElement('div');
  Object.assign(modal.style, {
    background: '#ffffff',
    color: '#1e293b',
    borderRadius: '16px',
    width: '440px',
    maxWidth: '90vw',
    maxHeight: '80vh',
    boxShadow: '0 24px 64px rgba(0,0,0,0.25)',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    transition: 'transform 0.25s',
    transform: 'scale(0.95)',
  });

  // ── Header ──
  const header = document.createElement('div');
  Object.assign(header.style, {
    padding: '20px 24px 16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottom: '1px solid #e2e8f0',
  });

  const titleRow = document.createElement('div');
  Object.assign(titleRow.style, { display: 'flex', alignItems: 'center', gap: '10px' });

  const statusIcon = document.createElement('div');
  Object.assign(statusIcon.style, {
    width: '24px', height: '24px',
    border: '2.5px solid #e2e8f0',
    borderTopColor: '#25af97',
    borderRadius: '50%',
    animation: 'imagenary-spin 0.6s linear infinite',
    flexShrink: '0',
  });

  const title = document.createElement('div');
  title.textContent = 'Extracting text...';
  Object.assign(title.style, { fontSize: '16px', fontWeight: '600' });

  titleRow.appendChild(statusIcon);
  titleRow.appendChild(title);

  const closeBtn = document.createElement('button');
  closeBtn.textContent = '\u00d7';
  Object.assign(closeBtn.style, {
    background: 'none', border: 'none', fontSize: '24px',
    cursor: 'pointer', color: '#94a3b8', lineHeight: '1',
    padding: '0 0 0 12px',
  });
  closeBtn.addEventListener('click', dismiss);

  header.appendChild(titleRow);
  header.appendChild(closeBtn);

  // ── Body (result area) ──
  const body = document.createElement('div');
  Object.assign(body.style, {
    padding: '20px 24px',
    flex: '1',
    overflowY: 'auto',
    display: 'none',
  });

  const textarea = document.createElement('textarea');
  textarea.readOnly = true;
  textarea.placeholder = 'Extracted text will appear here...';
  Object.assign(textarea.style, {
    width: '100%', minHeight: '140px', maxHeight: '300px',
    padding: '12px', border: '1px solid #e2e8f0', borderRadius: '8px',
    fontFamily: 'inherit', fontSize: '13px', lineHeight: '1.6',
    resize: 'vertical', background: '#f8fafc', color: '#1e293b',
    outline: 'none', boxSizing: 'border-box',
  });
  textarea.addEventListener('focus', () => { textarea.style.borderColor = '#25af97'; });
  textarea.addEventListener('blur', () => { textarea.style.borderColor = '#e2e8f0'; });
  body.appendChild(textarea);

  // Copy button row
  const actions = document.createElement('div');
  Object.assign(actions.style, {
    display: 'flex', gap: '8px', marginTop: '12px', alignItems: 'center',
  });

  const copyBtn = document.createElement('button');
  copyBtn.textContent = 'Copy to Clipboard';
  Object.assign(copyBtn.style, {
    background: '#25af97', color: '#fff', border: 'none',
    padding: '8px 16px', borderRadius: '8px', fontSize: '13px',
    fontWeight: '500', cursor: 'pointer',
  });
  copyBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(textarea.value).then(() => {
      copyBtn.textContent = 'Copied!';
      setTimeout(() => { copyBtn.textContent = 'Copy to Clipboard'; }, 2000);
    });
  });

  const copiedBadge = document.createElement('span');
  copiedBadge.textContent = '\u2713 Auto-copied to clipboard';
  Object.assign(copiedBadge.style, {
    fontSize: '12px', color: '#25af97', fontWeight: '500',
  });

  actions.appendChild(copyBtn);
  actions.appendChild(copiedBadge);
  body.appendChild(actions);

  // ── Footer (promo/ad) ──
  const footer = document.createElement('div');
  Object.assign(footer.style, {
    padding: '14px 24px',
    borderTop: '1px solid #e2e8f0',
    background: '#f8fafc',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    fontSize: '13px',
  });

  const footerLeft = document.createElement('span');
  footerLeft.style.color = '#64748b';

  const footerRight = document.createElement('a');
  footerRight.href = 'https://www.imagenary.ai';
  footerRight.target = '_blank';
  footerRight.textContent = 'ScreenScribe by Imagenary AI \u2192';
  Object.assign(footerRight.style, {
    color: '#25af97', textDecoration: 'none', fontWeight: '600',
  });

  footer.appendChild(footerLeft);
  footer.appendChild(footerRight);

  // Assemble
  modal.appendChild(header);
  modal.appendChild(body);
  modal.appendChild(footer);
  backdrop.appendChild(modal);

  // Keyframes
  const style = document.createElement('style');
  style.textContent = `@keyframes imagenary-spin { to { transform: rotate(360deg); } }`;
  document.head.appendChild(style);

  document.body.appendChild(backdrop);

  // Animate in
  requestAnimationFrame(() => {
    backdrop.style.opacity = '1';
    modal.style.transform = 'scale(1)';
  });

  // Close on backdrop click
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) dismiss();
  });

  // Close on Esc
  function onKey(e) { if (e.key === 'Escape') dismiss(); }
  document.addEventListener('keydown', onKey);

  function dismiss() {
    backdrop.style.opacity = '0';
    modal.style.transform = 'scale(0.95)';
    setTimeout(() => { backdrop.remove(); style.remove(); }, 250);
    document.removeEventListener('keydown', onKey);
  }

  // Listen for result from background
  chrome.runtime.onMessage.addListener(function handler(msg) {
    if (msg.action === 'toast-result') {
      chrome.runtime.onMessage.removeListener(handler);

      // Stop spinner, show result
      statusIcon.style.animation = 'none';
      statusIcon.style.border = 'none';

      if (msg.error) {
        statusIcon.textContent = '\u2717';
        Object.assign(statusIcon.style, {
          color: '#ef4444', fontSize: '20px', fontWeight: 'bold',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        });
        title.textContent = msg.error;
        title.style.color = '#ef4444';

        if (msg.exhausted) {
          footerLeft.textContent = 'Free extractions used up';
          footerRight.href = 'https://www.imagenary.ai/pricing';
          footerRight.textContent = 'Get More \u2192';
        }
      } else {
        statusIcon.textContent = '\u2713';
        Object.assign(statusIcon.style, {
          color: '#25af97', fontSize: '20px', fontWeight: 'bold',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        });
        title.textContent = 'Text Extracted';

        body.style.display = 'block';
        textarea.value = msg.text;

        // Footer promo
        if (msg.remaining === Infinity || msg.remaining === undefined) {
          footerLeft.textContent = 'Powered by';
        } else if (msg.remaining <= 0) {
          footerLeft.textContent = 'Last free extraction!';
          footerRight.href = 'https://www.imagenary.ai/pricing';
          footerRight.textContent = 'Get More \u2192';
        } else {
          footerLeft.textContent = msg.remaining + ' free extraction' + (msg.remaining === 1 ? '' : 's') + ' remaining';
        }
      }
    }
  });

  // Safety net
  setTimeout(() => {
    if (document.getElementById(ID)) dismiss();
  }, 60000);
})();
